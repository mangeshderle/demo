<?php
# Database Configuration
define( 'DB_NAME', 'wp_test321devdev' );
define( 'DB_USER', 'test321devdev' );
define( 'DB_PASSWORD', 'k3u_ZSF7wrv1LFxjhZ2c' );
define( 'DB_HOST', '127.0.0.1:3306' );
define( 'DB_HOST_SLAVE', '127.0.0.1:3306' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY',         'v%PR`}?78`U0/d?ve6Oc<nVQ#uvKD]i$WkZ|7^9 *+M_3-=30.~:ipDGC9`o8b+)');
define('SECURE_AUTH_KEY',  'Hu|}wbGF+jNM>oWc-k&Gv_#B,;C^6t#^?Ak0=&Ryuf[0>knPNbP.;C|^h.L8- G4');
define('LOGGED_IN_KEY',    'ozcZ:Pil`a/;1@dWwyG&|@[V|cmV&cTM[|qO}^](e-oW!fi$btLq+eOgnWpgD2-]');
define('NONCE_KEY',        'VKlbS3Fg:$nm}Dure!rI+Admb>4{pwUIee2;4uBm`cPJ^=)J$l{<ro2_ /jH];}L');
define('AUTH_SALT',        'a[+)]<J9enh>G.gidxOv#d4!D@(IGBgc<E:0|djM<t-}LY-T<eMe+B+=fyC6~+t_');
define('SECURE_AUTH_SALT', 'AXh)#$?1Y<7QQJ>xiqP[y/8R|]M%o&+Iq;)`~,t5Wq|uwo_Kj`!`HEHteTM$8,P[');
define('LOGGED_IN_SALT',   'BgIR&|;&d0d*,7-^(#G:(-6#|-x a)p2CZCKV@C-W>x|-5)HD8L{-ox3+e<MOqE|');
define('NONCE_SALT',       '4 G_{H+<_|*{Q.8IR`}&6+$$rTG0I7d+~n`?JB2F%qQiZ[J7Q4n 34x^J2*+CK_[');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'test321devdev' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'WPE_APIKEY', '7c377aca26270b2e6a3d07cc7f057b298068efa9' );

define( 'WPE_CLUSTER_ID', '151633' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_SFTP_ENDPOINT', '' );

define( 'WPE_LBMASTER_IP', '' );

define( 'WPE_CDN_DISABLE_ALLOWED', true );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'test321devdev.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-151633', );

$wpe_special_ips=array ( 0 => '104.198.100.248', );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', __DIR__ . '/');
require_once(ABSPATH . 'wp-settings.php');
